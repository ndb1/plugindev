=== comment-add ===
Contributors: Shebin
Tags: 
Requires at least: 1.0
Tested up to: 1.0
License: GPLv2 or later



== Description ==

plugin can be used for 
1.For Form
2.header and footer scripts


Major features include:

* can send the form details to a mail
* can add the form detail to the database
*can add form data to comment and see later

== Installation ==

Upload the comment-add plugin to your blog, Activate it.





= 1.0=
*Release Date - 29 may 2018*


= 1.0.1 =
*Release Date - 30 may 2018*

* Fixed a bug that could cause Akismet to recheck a comment that has already been manually approved or marked as spam.
* Fixed a bug that could cause Akismet to claim that some comments are still waiting to be checked when no comments are waiting to be checked.
